


// nav toggle
const links = document.querySelector('.links');
const navLinks = document.querySelector('.nav-links');

links.addEventListener('click', () => {
    
    navLinks.classList.toggle('active');
});
